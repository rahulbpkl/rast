class Vector
{
public void  nop() {
  while (true) {
	  // Thread.sleep(DURATION);
	  }
}}
class Vector1
{
public void  nop() {
  while (true) {
	  // Thread.sleep(DURATION);
	  }
}}
