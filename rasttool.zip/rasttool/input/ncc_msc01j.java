class mcc_msc01j
{
public void  nop() {
  while (true) {
	  // Thread.sleep(DURATION);
	  }
}}
