import java.io.File;
 

class ncc_fio02j {
	public static void main(String args[]){
		File file = new File("file");
	file.delete();
}
	}
	
